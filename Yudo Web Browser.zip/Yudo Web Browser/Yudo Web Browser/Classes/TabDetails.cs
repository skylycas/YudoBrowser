﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace Yudo_Web_Browser.Classes
{
    internal class TabDetails
    {
        public string YudoTabHeaderTitle { get; set; }
        public BitmapImage YudoTabHeaderFavicon { get; set; }
        public string SiteUrl { get; set; }
    }
}
