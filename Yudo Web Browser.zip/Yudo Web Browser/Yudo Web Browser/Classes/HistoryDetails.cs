﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yudo_Web_Browser.Classes
{
    internal class HistoryDetails
    {

        public string ImageSource   { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
