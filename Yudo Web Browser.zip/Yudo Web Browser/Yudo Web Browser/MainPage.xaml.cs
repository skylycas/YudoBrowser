﻿using Microsoft.UI.Xaml.Controls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Yudo_Web_Browser.Classes;
using Windows.Media;
using Yudo_Web_Browser.YudoControls;
using YudoDataLibrary;
using System.Drawing;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Yudo_Web_Browser
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public static MainPage Current;

        CoreApplicationViewTitleBar coreApplicationViewTitleBar;
        ApplicationViewTitleBar applicationViewTitleBar;
        public MainPage()
        {
            this.InitializeComponent();

            Current = this;

            coreApplicationViewTitleBar = CoreApplication.GetCurrentView().TitleBar;
            coreApplicationViewTitleBar.ExtendViewIntoTitleBar = true;

            applicationViewTitleBar = ApplicationView.GetForCurrentView().TitleBar;
            applicationViewTitleBar.ButtonBackgroundColor = Colors.Transparent;

            Window.Current.SetTitleBar(myTitleBar);

            coreApplicationViewTitleBar.LayoutMetricsChanged += CoreApplicationViewTitleBar_LayoutMetricsChanged;
            coreApplicationViewTitleBar.IsVisibleChanged += CoreApplicationViewTitleBar_IsVisibleChanged;

            Window.Current.CoreWindow.Activated += CoreWindow_Activated;

            LoadDefaultTab();
        }

        private void LoadDefaultTab()
        {


            defaultTab.HeaderTemplate = Application.Current.Resources["YudoTabHeaderTemplate"] as DataTemplate;
            
            TabContent tabContent = new TabContent();
            tabContent.currentTab = defaultTab;
            //tabContent.WebAddress = "http://triosdevelopers.com/~U.Maduabuna/BrowserDefault/BlankPage.html";
            tabContent.WebAddress = "https://www.google.com";
            defaultTab.Content = tabContent;
        }

        private void CoreWindow_Activated(CoreWindow sender, WindowActivatedEventArgs args)
        {
            //UISettings uISettings = new UISettings();
            //if(args.WindowActivationState == CoreWindowActivationState.Deactivated)
            //{
            //    myTitleBar.Background = new SolidColorBrush(Colors.DarkOrange);
            //    //myTitleBar.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#ffaacc"));
            //}
            //else
            //{
            //    myTitleBar.Background = new SolidColorBrush(Colors.DarkOrange);
            //}
        }

        private void CoreApplicationViewTitleBar_LayoutMetricsChanged(CoreApplicationViewTitleBar sender, object args)
        {
            LefPaddingColumn.Width = new GridLength(coreApplicationViewTitleBar.SystemOverlayLeftInset);
            RightPaddingColumn.Width = new GridLength(coreApplicationViewTitleBar.SystemOverlayRightInset);
        }

        private void CoreApplicationViewTitleBar_IsVisibleChanged(CoreApplicationViewTitleBar sender, object args)
        {
            if (sender.IsVisible)
            {
                myTitleBar.Visibility = Visibility.Visible;
            }
            else
            {
                myTitleBar.Visibility = Visibility.Collapsed;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            //udotabContent.WebAddress = "https://www.google.com";
        }

        //string blankwebpath = $"ms-appx-web:///Assets/BlankPage.html";
        public void AddTab(string address = "http://triosdevelopers.com/~U.Maduabuna/BrowserDefault/BlankPage.html")
        {
            var newTab = new TabViewItem();
            newTab.HeaderTemplate = Application.Current.Resources["YudoTabHeaderTemplate"] as DataTemplate;
            //newTab.IconSource = new Microsoft.UI.Xaml.Controls.SymbolIconSource()
            //{
            //    Symbol = Symbol.Document
            //};
            //newTab.Header = "New Document";

           // TabDetails tabDetails = new TabDetails();
           // tabDetails.YudoTabHeaderTitle = "Google";
           // tabDetails.SiteUrl = "https://www.google.com";
           //// tabDetails.YudoTabHeaderFavicon = "";
           // newTab.DataContext = tabDetails;


            TabContent tabContent = new TabContent();
            tabContent.currentTab = newTab;
            tabContent.WebAddress = address;
            newTab.Content = tabContent;

            myTabView.TabItems.Add(newTab);
            myTabView.SelectedItem = newTab;

        }

        private void TabView_AddTabButtonClick(Microsoft.UI.Xaml.Controls.TabView sender, object args)
        {
            //var newTab = new TabViewItem();
            //newTab.IconSource = new Microsoft.UI.Xaml.Controls.SymbolIconSource()
            //{
            //   Symbol = Symbol.Document
            //};
            //newTab.Header = "New Document";
            //TabContent tabContent = new TabContent();
            //tabContent.WebAddress = "https://www.google.com";
            //newTab.Content = tabContent;

            //sender.TabItems.Add(newTab);

            AddTab();

        }

        private void TabView_TabCloseRequested(Microsoft.UI.Xaml.Controls.TabView sender, Microsoft.UI.Xaml.Controls.TabViewTabCloseRequestedEventArgs args)
        {
            if(myTabView.TabItems.Count > 1)
            {
                sender.TabItems.Remove(args.Tab);
               
            }
            else
            {
                sender.TabItems.Remove(args.Tab);
                Environment.Exit(0);
            }
        }
    }
}
