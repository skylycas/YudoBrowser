﻿using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Yudo_Web_Browser.Classes;
using YudoDataLibrary;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Yudo_Web_Browser.YudoControls
{
    public sealed partial class TabContent : UserControl
    {
        List<string> searchWordsLocal = new List<string>();

        public TabViewItem currentTab;
        public TabContent()
        {
            this.InitializeComponent();
        }

        public string WebAddress
        {
            get { return (string)GetValue(WebAddressProperty); }
            set { SetValue(WebAddressProperty, value); }
        }

        // Using a DependencyProperty as the backing store for WebAddress.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty WebAddressProperty =
            DependencyProperty.Register("WebAddress", typeof(string), typeof(TabContent), new PropertyMetadata("http://www.google.com"));

        private void AutoSuggestBox_QuerySubmitted(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            //MessageDialog message = new MessageDialog(sender.Text);
            //await message.ShowAsync();


            if (!String.IsNullOrEmpty(sender.Text))
            {
                //Add the search workd to the database tabble tblsearch
               DataAccess.addsearchesToDatabase(sender.Text, DateTime.Now, 0);

                //Search string and navidate
                wvBrowser.Source = new Uri("https://www.google.com/search?q=" + sender.Text);
                GetSearchWordList();
            }
        }

        private void txtautosuggestBox_SuggestionChosen(AutoSuggestBox sender, AutoSuggestBoxSuggestionChosenEventArgs args)
        {
            //Search string and navidate
            wvBrowser.Source = new Uri("https://www.google.com/search?q=" + sender.Text);
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if(wvBrowser.CanGoBack)
            {
                wvBrowser.GoBack();
            }
        }
        private void txtautosuggestBox_GotFocus(object sender, RoutedEventArgs e)
        {
            GetSearchWordList();

            //Debug.WriteLine("Got Focus");
        }

        private void txtautosuggestBox_TextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args)
        {
            if (args.Reason == AutoSuggestionBoxTextChangeReason.UserInput)
            {
                sender.ItemsSource = searchWordsLocal;
            }

            if (args.Reason == AutoSuggestionBoxTextChangeReason.UserInput && !string.IsNullOrEmpty(sender.Text))
            {
                var searched = searchWordsLocal;
                List<string> filteredsearchword = new List<string>();
                foreach (var searchItem in searched)
                {
                    if (searchItem.ToLower().Contains(sender.Text.ToLower()))
                    {
                        filteredsearchword.Add(searchItem);
                    }
                }

                sender.ItemsSource = filteredsearchword;
            }
            else
            {
                GetSearchWordList();
                sender.ItemsSource = null;
            }
        }

        private void GetSearchWordList()
        {
            //clear the search word list
            searchWordsLocal.Clear();
            //get all previously saved search words from the database
           searchWordsLocal = DataAccess.GetAllSearchWords();
        }
        private void btnForward_Click(object sender, RoutedEventArgs e)
        {
            if(wvBrowser.CanGoForward)
            {
                wvBrowser.GoForward();
            }                
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            wvBrowser.Source = new Uri("https://www.google.com");
        }

        private void newTabMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MainPage.Current.AddTab();
        }

        private void wvBrowser_NavigationCompleted(Microsoft.UI.Xaml.Controls.WebView2 sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs args)
        {
            currentTab.HeaderTemplate = Application.Current.Resources["YudoTabHeaderTemplate"] as DataTemplate;

            TabDetails tabDetails = new TabDetails();
            tabDetails.SiteUrl = wvBrowser.CoreWebView2.Source;
            tabDetails.YudoTabHeaderTitle = wvBrowser.CoreWebView2.DocumentTitle;

            BitmapImage bmi = new BitmapImage(new Uri("https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=" + tabDetails.SiteUrl + "&size=16"));
            tabDetails.YudoTabHeaderFavicon = bmi;
            currentTab.DataContext = tabDetails;

            // add string to URL texbox (auto suggest box)

            txtautosuggestBox.Text = wvBrowser.CoreWebView2.Source;


            btnstop.Visibility = Visibility.Collapsed;

            browserProgressBar.Visibility = Visibility.Collapsed;
            

        }

        private void menuitemDownloads_Click(object sender, RoutedEventArgs e)
        {
            wvBrowser.CoreWebView2.OpenDefaultDownloadDialog();
        }

        private void menuitemDevtools_Click(object sender, RoutedEventArgs e)
        {
            wvBrowser.CoreWebView2.OpenDevToolsWindow();
        }

        private void btnrefresh_Click(object sender, RoutedEventArgs e)
        {
            wvBrowser.CoreWebView2.Reload();
        }

        private void btnstop_Click(object sender, RoutedEventArgs e)
        {
            wvBrowser.CoreWebView2.Stop();
        }

        private void wvBrowser_NavigationStarting(WebView2 sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationStartingEventArgs args)
        {
            btnstop.Visibility = Visibility.Visible;
            browserProgressBar.Visibility = Visibility.Visible;
        }

        private void wvBrowser_CoreWebView2Initialized(WebView2 sender, CoreWebView2InitializedEventArgs args)
        {
            wvBrowser.CoreWebView2.NewWindowRequested += WVBrowser_NewWindowRequested;
            wvBrowser.Source = new Uri(WebAddress);
        }

        private void WVBrowser_NewWindowRequested(CoreWebView2 sender, CoreWebView2NewWindowRequestedEventArgs args)
        {
            args.Handled = true;
            MainPage.Current.AddTab(args.Uri);
        }

        private async void menuitemHistory_Click(object sender, RoutedEventArgs e)
        {
            var histroyList = await DataAccess.GetHistoryDetails();

            foreach (var item in histroyList)
            {
                ListViewItem listViewItem = new ListViewItem();
                listViewItem.ContentTemplate = Application.Current.Resources["lvHistoryListDataTemplate"] as DataTemplate;
                item.ImageSource = new BitmapImage(new Uri("https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=" + item.Url + "&size=16"));
                listViewItem.DataContext = item;

                listViewItem.Tag = item.Url;

                lvHistoryList.Items.Add(listViewItem);
            }

            historyFlyoutMenu.ShowAt(btnMenu);
            historyFlyoutMenu.Placement = FlyoutPlacementMode.TopEdgeAlignedRight;
        }

        private void btnmenuitemSearchFlyout_Click(object sender, RoutedEventArgs e)
        {
            ToggleSearchHistoryTextBox();
        }

        private void ToggleSearchHistoryTextBox()
        {
            if (txthistorysearch.Visibility == Visibility.Collapsed)
            {
                txthistorysearch.Visibility = Visibility.Visible;
            }
            else
            {
                txthistorysearch.Visibility = Visibility.Collapsed;
            }
        }

        private void lvHistoryList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListViewItem item = lvHistoryList.SelectedItem as ListViewItem;
            wvBrowser.Source = new Uri(item.Tag.ToString());
        }
    }
}
