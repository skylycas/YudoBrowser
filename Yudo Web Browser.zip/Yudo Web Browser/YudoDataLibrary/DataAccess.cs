﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using Windows.Storage;
using YudoDataLibrary.Classes;

namespace YudoDataLibrary
{
    public static class DataAccess
    {
        public static async Task<List<HistoryDetails>> GetHistoryDetails()
        {
            List<HistoryDetails> historyDetails = new List<HistoryDetails>();
            //get database path for History
            StorageFolder EBWebViewFolder = await ApplicationData.Current.LocalFolder.GetFolderAsync("EBWebView");
            StorageFolder DefaultFolder = await EBWebViewFolder.GetFolderAsync("Default");
            StorageFile HistoryFile = await DefaultFolder.GetFileAsync("History");

            string dbpath = HistoryFile.Path;

            using (SqliteConnection connection = new SqliteConnection($"Filename={dbpath}"))
            {
                connection.Open();

                string selectquery = "SELECT url, title FROM urls";
                SqliteCommand command = new SqliteCommand(selectquery, connection);
                SqliteDataReader sqliteDataReader = command.ExecuteReader();
                while(sqliteDataReader.Read())
                {
                    HistoryDetails hd = new HistoryDetails();
                    hd.Url = sqliteDataReader.GetString(0);
                    hd.Title = sqliteDataReader.GetString(1);

                    historyDetails.Add(hd);
                }
                connection.Close();
            }
            return historyDetails;
        }
        static string databasePath = "webbrowser.db";
        //This will create database and its tables
        public static async void CreateDatabase()
        {
            await ApplicationData.Current.LocalFolder.CreateFileAsync(databasePath, CreationCollisionOption.OpenIfExists);
            string newdatabasePath = Path.Combine(ApplicationData.Current.LocalFolder.Path, databasePath);

            using (SqliteConnection connection = new SqliteConnection($"Filename={newdatabasePath}"))
            {
                connection.Open();
                string searchCommand = "CREATE TABLE IF NOT EXISTS tblSearch (searchID INTEGER PRIMARY KEY,searchword VARCHAR(2048) NOT NULL, datecreated DATE, searchcount INTEGER)";

                SqliteCommand sqliteCommand = new SqliteCommand(searchCommand, connection);
                sqliteCommand.ExecuteReader();
            }
        }

        public static void addsearchesToDatabase(string searchword, DateTime createddate, int searchcount)
        {
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, databasePath);
            using (SqliteConnection connection = new SqliteConnection($"Filename={dbpath}"))
            {
                connection.Open();
                SqliteCommand sqliteInsertCommand = new SqliteCommand();
                sqliteInsertCommand.Connection = connection;

                sqliteInsertCommand.CommandText = "INSERT INTO tblSearch VALUES(NULL, @searchword, @createddate, @searchcount)";
                sqliteInsertCommand.Parameters.AddWithValue("@searchword", searchword);
                sqliteInsertCommand.Parameters.AddWithValue("@createddate", createddate);
                sqliteInsertCommand.Parameters.AddWithValue("@searchcount", searchcount);

                sqliteInsertCommand.ExecuteReader();
                connection.Close();
            }
        }

        public static List<string> GetAllSearchWords()
        {
            List<string> words = new List<string>();
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, databasePath);
            using (SqliteConnection connection = new SqliteConnection($"Filename={dbpath}"))
            {
                connection.Open();
                string selectQuery = "SELECT DISTINCT searchword from tblSearch";
                SqliteCommand sqliteSelectCommand = new SqliteCommand(selectQuery, connection);
                SqliteDataReader sqliteDataReader = sqliteSelectCommand.ExecuteReader();
                while (sqliteDataReader.Read())
                {
                    words.Add(sqliteDataReader.GetString(0));
                }
                connection.Close();
            }
            return words;
        }
    }
}
